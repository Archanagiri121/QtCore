
#include "randomnumbergenerator.h"
#include <QRandomGenerator>

RandomNumberGenerator::RandomNumberGenerator(QObject *parent)
    : QObject{parent}
{}

int RandomNumberGenerator::generateRandomNumber(int min, int max)
{
    int randomNumber = QRandomGenerator::global()->bounded(min, max);

    if (randomNumber % 2 == 0) {
        m_evenNumbers += QString::number(randomNumber) + "\n";
        emit evenNumbersChanged();
    } else {
        m_oddNumbers += QString::number(randomNumber) + "\n";
        emit oddNumbersChanged();
    }

    return randomNumber;
}


