#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "randomnumbergenerator.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    qmlRegisterType<RandomNumberGenerator>("CustomTypes", 1, 0, "RandomNumberGenerator");

    QQmlApplicationEngine engine;
    const QUrl url(u"qrc:/randomgeneratorEvenOdd/main.qml"_qs);
    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreated,
        &app,
        [url](QObject *obj, const QUrl &objUrl) {
            if (!obj && url == objUrl)
                QCoreApplication::exit(-1);
        },
        Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
