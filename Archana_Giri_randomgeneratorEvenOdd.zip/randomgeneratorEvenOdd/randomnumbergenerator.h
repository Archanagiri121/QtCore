#ifndef RANDOMNUMBERGENERATOR_H
#define RANDOMNUMBERGENERATOR_H

#include <QObject>

class RandomNumberGenerator : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString evenNumbers READ evenNumbers NOTIFY evenNumbersChanged)
    Q_PROPERTY(QString oddNumbers READ oddNumbers NOTIFY oddNumbersChanged)

public:
    explicit RandomNumberGenerator(QObject *parent = nullptr);

    QString evenNumbers() const { return m_evenNumbers; }
    QString oddNumbers() const { return m_oddNumbers; }


public slots:
    int generateRandomNumber(int min, int max);

signals:
    void randomNumberGenerated(int number);
    void evenNumbersChanged();
    void oddNumbersChanged();

private:
    QString m_evenNumbers;
    QString m_oddNumbers;
};

#endif // RANDOMNUMBERGENERATOR_H
